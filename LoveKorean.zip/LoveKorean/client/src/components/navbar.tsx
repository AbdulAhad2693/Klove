import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  return (
    <nav className="fixed top-0 w-full bg-white border-b border-gray-200 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link href="/">
            <a className="text-2xl font-bold text-primary">Learn Korean for Love</a>
          </Link>

          <div className="flex items-center space-x-4">
            <NavLink href="/practice" active={location === "/practice"}>
              Chat Practice
            </NavLink>
            {user ? (
              <Button 
                variant="ghost" 
                onClick={() => logoutMutation.mutate()}
                disabled={logoutMutation.isPending}
              >
                Logout
              </Button>
            ) : (
              <NavLink href="/auth" active={location === "/auth"}>
                Login
              </NavLink>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link href={href}>
      <a
        className={cn(
          "px-3 py-2 rounded-md text-sm font-medium",
          active
            ? "bg-primary text-white"
            : "text-gray-700 hover:bg-primary/10"
        )}
      >
        {children}
      </a>
    </Link>
  );
}