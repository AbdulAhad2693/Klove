import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { type Lesson } from "@shared/schema";

interface LessonCardProps {
  lesson: Lesson;
  onClick: () => void;
}

export function LessonCard({ lesson, onClick }: LessonCardProps) {
  const getDifficultyColor = (difficulty: number) => {
    switch (difficulty) {
      case 1: return "bg-green-500";
      case 2: return "bg-blue-500";
      case 3: return "bg-yellow-500";
      case 4: return "bg-orange-500";
      case 5: return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Fundamentals": return "border-green-200 bg-green-100 text-green-800";
      case "Daily Life": return "border-blue-200 bg-blue-100 text-blue-800";
      case "K-Drama": return "border-pink-200 bg-pink-100 text-pink-800";
      case "K-Pop": return "border-purple-200 bg-purple-100 text-purple-800";
      case "Culture": return "border-yellow-200 bg-yellow-100 text-yellow-800";
      case "Business": return "border-gray-200 bg-gray-100 text-gray-800";
      default: return "border-gray-200 bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card 
      className="cursor-pointer hover:shadow-lg transition-shadow"
      onClick={onClick}
    >
      <div className="aspect-video relative overflow-hidden rounded-t-lg">
        <img
          src={lesson.imageUrl}
          alt={lesson.title}
          className="object-cover w-full h-full"
        />
        <div className="absolute top-2 right-2 flex gap-2">
          <Badge 
            className={`${getDifficultyColor(lesson.difficulty)} text-white`}
          >
            Level {lesson.difficulty}
          </Badge>
        </div>
      </div>
      <CardHeader>
        <CardTitle className="text-lg">{lesson.title}</CardTitle>
        <CardDescription>{lesson.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <Badge 
          variant="outline" 
          className={getCategoryColor(lesson.category)}
        >
          {lesson.category}
        </Badge>
      </CardContent>
    </Card>
  );
}