import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Send } from "lucide-react";

interface ChatResponse {
  friendly_reaction: string;
  formal: { korean: string; romanized: string };
  casual: { korean: string; romanized: string };
  english: string;
  grammar: string;
  cultural_note: string;
  difficulty: number;
  related_vocab: Array<{ korean: string; romanized: string; english: string }>;
  correction?: string;
}

interface Message {
  type: "user" | "model";
  content: string | ChatResponse;
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const { toast } = useToast();

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const res = await apiRequest("POST", "/api/chat", {
        message,
        history: messages.map(msg => ({
          role: msg.type,
          content: typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content)
        }))
      });
      return res.json();
    },
    onSuccess: (data: ChatResponse) => {
      setMessages((prev) => [...prev, { type: "model", content: data }]);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to send message"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setMessages((prev) => [...prev, { type: "user", content: input }]);
    chatMutation.mutate(input);
    setInput("");
  };

  const getDifficultyColor = (level: number) => {
    switch (level) {
      case 1: return "bg-green-500";
      case 2: return "bg-blue-500";
      case 3: return "bg-yellow-500";
      case 4: return "bg-orange-500";
      case 5: return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const renderMessage = (msg: Message) => {
    if (msg.type === "user") {
      return (
        <div className="inline-block max-w-[80%] bg-primary text-white rounded-lg p-3">
          <p>{msg.content as string}</p>
        </div>
      );
    }

    const response = msg.content as ChatResponse;
    return (
      <div className="space-y-4 max-w-[80%]">
        {/* Friendly Reaction */}
        <p className="text-lg text-gray-800 italic">
          {response.friendly_reaction}
        </p>

        <Card>
          <CardContent className="p-4 space-y-4">
            {/* Casual Expression First */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <Badge variant="outline">Casual</Badge>
                <Badge 
                  className={`${getDifficultyColor(response.difficulty)} text-white`}
                >
                  Level {response.difficulty}
                </Badge>
              </div>
              <p className="text-lg font-bold">{response.casual.korean}</p>
              <p className="text-sm text-gray-600 italic">
                {response.casual.romanized}
              </p>
            </div>

            {/* Formal Expression Second */}
            <div>
              <Badge variant="outline">Formal</Badge>
              <p className="text-lg font-bold mt-1">{response.formal.korean}</p>
              <p className="text-sm text-gray-600 italic">
                {response.formal.romanized}
              </p>
            </div>

            <div className="border-t pt-2">
              <p className="text-base">{response.english}</p>
            </div>

            {/* Grammar Explanation */}
            <div className="bg-gray-50 p-3 rounded-md">
              <p className="text-sm text-gray-700">{response.grammar}</p>
            </div>

            {/* Cultural Note - Now with K-pop/K-drama references */}
            <div className="bg-blue-50 p-3 rounded-md">
              <p className="text-sm text-blue-700">{response.cultural_note}</p>
            </div>

            {/* Correction if available */}
            {response.correction && (
              <div className="bg-yellow-50 p-3 rounded-md">
                <p className="text-sm text-yellow-700">{response.correction}</p>
              </div>
            )}

            {/* Related Vocabulary */}
            <div className="border-t pt-2">
              <p className="font-medium mb-2">Related Expressions:</p>
              <div className="space-y-2">
                {response.related_vocab.map((vocab, index) => (
                  <div key={index} className="text-sm">
                    <span className="font-bold">{vocab.korean}</span>
                    <span className="text-gray-600 mx-2">({vocab.romanized})</span>
                    <span>{vocab.english}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <Card className="flex flex-col h-[600px] max-w-4xl mx-auto">
      <ScrollArea className="flex-1 p-4">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`mb-6 ${
              msg.type === "user" ? "text-right" : "text-left"
            }`}
          >
            {renderMessage(msg)}
          </div>
        ))}
      </ScrollArea>
      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Chat with your Korean friend..."
            className="flex-1"
          />
          <Button type="submit" disabled={chatMutation.isPending}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>
    </Card>
  );
}