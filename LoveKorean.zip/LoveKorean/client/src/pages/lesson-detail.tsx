import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useParams } from "wouter";
import { type Lesson } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Volume2 } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function LessonDetail() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: lesson, isLoading } = useQuery<Lesson>({
    queryKey: [`/api/lessons/${id}`],
  });

  const progressMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/progress", {
        lessonId: Number(id),
        userId: 1, // TODO: Replace with actual user ID when auth is implemented
        completed: true,
        score: 100,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
      toast({
        title: "Progress Saved",
        description: "Great job completing the lesson!",
      });
    },
  });

  if (isLoading || !lesson) {
    return (
      <div className="min-h-screen pt-16 px-4">
        <div className="max-w-3xl mx-auto animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/2 mb-4" />
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-8" />
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 px-4">
      <div className="max-w-3xl mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">{lesson.title}</h1>
          <p className="text-gray-600 mb-4">{lesson.description}</p>
          <Progress value={33} className="w-full" />
        </div>

        <div className="space-y-4">
          {lesson.phrases.map((phrase: any, index: number) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <p className="text-2xl font-bold mb-2">{phrase.korean}</p>
                    <p className="text-gray-600 italic mb-2">{phrase.romanized}</p>
                    <p className="text-gray-800">{phrase.meaning}</p>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Volume2 className="h-6 w-6" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 flex justify-end">
          <Button
            size="lg"
            onClick={() => progressMutation.mutate()}
            disabled={progressMutation.isPending}
          >
            Complete Lesson
          </Button>
        </div>
      </div>
    </div>
  );
}
