import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-12 md:py-20">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 sm:text-6xl">
              Learn Korean through K-Culture
            </h1>
            <p className="mt-6 text-lg text-gray-600 max-w-3xl mx-auto">
              Practice Korean conversation with our AI tutor that understands K-pop, K-dramas, 
              and Korean culture. Get instant feedback and learn natural expressions used in 
              your favorite content.
            </p>
            <div className="mt-10">
              <Link href="/practice">
                <Button size="lg" className="text-lg">
                  Start Chatting
                </Button>
              </Link>
            </div>
          </div>

          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                image: "https://images.unsplash.com/photo-1681921761664-3b3b0d69331c",
                title: "K-Drama Context",
                description: "Learn expressions from trending dramas like 'Squid Game' and 'Goblin'"
              },
              {
                image: "https://images.unsplash.com/photo-1681921761664-3b3b0d69331c",
                title: "K-Pop Culture",
                description: "Practice with lyrics from BTS, BLACKPINK, and more"
              },
              {
                image: "https://images.unsplash.com/photo-1681921761664-3b3b0d69331c",
                title: "Modern Korean",
                description: "Learn contemporary slang and internet expressions"
              }
            ].map((feature, i) => (
              <div key={i} className="text-center">
                <div className="rounded-lg overflow-hidden aspect-video mb-4">
                  <img
                    src={feature.image}
                    alt={feature.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">
                  {feature.title}
                </h3>
                <p className="mt-2 text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}