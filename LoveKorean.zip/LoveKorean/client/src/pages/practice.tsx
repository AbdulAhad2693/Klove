import { ChatInterface } from "@/components/chat-interface";

export default function Practice() {
  return (
    <div className="min-h-screen pt-16 px-4">
      <div className="max-w-7xl mx-auto py-8">
        <h1 className="text-3xl font-bold mb-8">Practice Conversation</h1>
        <p className="text-gray-600 mb-8">
          Chat with our AI language partner to practice your Korean. Try asking questions
          or responding to prompts in Korean or English.
        </p>
        <ChatInterface />
      </div>
    </div>
  );
}
