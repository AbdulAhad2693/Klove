import { type User, type InsertUser, type Lesson, type Progress, type InsertProgress, type Chat, type InsertChat } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  saveChat(chat: InsertChat): Promise<Chat>;
  getUserChats(userId: number): Promise<Chat[]>;
  getLessons(): Promise<Lesson[]>;
  getLessonById(id: number): Promise<Lesson | undefined>;
  getProgress(userId: number): Promise<Progress[]>;
  updateProgress(progress: InsertProgress): Promise<Progress>;
  sessionStore: session.Store;
}

const MemoryStore = createMemoryStore(session);

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private lessons: Map<number, Lesson>;
  private progress: Map<number, Progress>;
  private chats: Map<number, Chat>;
  private currentId: { users: number; progress: number; chats: number };
  public sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.lessons = new Map();
    this.progress = new Map();
    this.chats = new Map();
    this.currentId = { users: 1, progress: 1, chats: 1 };
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Prune expired entries every 24h
    });

    // Initialize with comprehensive lessons
    const sampleLessons: Lesson[] = [
      // Basic Fundamentals
      {
        id: 1,
        title: "Hangul Basics",
        description: "Master the Korean alphabet and basic pronunciation",
        category: "Fundamentals",
        difficulty: 1,
        phrases: [
          { korean: "안녕하세요", romanized: "annyeonghaseyo", meaning: "Hello (formal)" },
          { korean: "안녕", romanized: "annyeong", meaning: "Hi (casual)" },
          { korean: "감사합니다", romanized: "gamsahamnida", meaning: "Thank you (formal)" },
          { korean: "고마워", romanized: "gomawo", meaning: "Thanks (casual)" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1652004329896-f78a898ffcb7"
      },
      {
        id: 2,
        title: "Numbers & Counting",
        description: "Learn Korean number systems and counting",
        category: "Fundamentals",
        difficulty: 1,
        phrases: [
          { korean: "하나, 둘, 셋", romanized: "hana, dul, set", meaning: "One, two, three" },
          { korean: "일, 이, 삼", romanized: "il, i, sam", meaning: "One, two, three (Sino-Korean)" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb"
      },
      // Daily Conversations
      {
        id: 3,
        title: "Ordering Food",
        description: "Essential phrases for restaurants and cafes",
        category: "Daily Life",
        difficulty: 2,
        phrases: [
          { korean: "이것 주세요", romanized: "igeos juseyo", meaning: "This one, please" },
          { korean: "맛있어요", romanized: "mashisseoyo", meaning: "It's delicious" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1532347922424-c652d9b7208e"
      },
      {
        id: 4,
        title: "Shopping Essentials",
        description: "Navigate Korean markets and stores",
        category: "Daily Life",
        difficulty: 2,
        phrases: [
          { korean: "얼마예요?", romanized: "eolmayeyo?", meaning: "How much is it?" },
          { korean: "너무 비싸요", romanized: "neomu bissayo", meaning: "It's too expensive" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1583417319070-4a69db38a482"
      },
      // K-Drama Scenarios
      {
        id: 5,
        title: "Romance 101",
        description: "Sweet expressions from your favorite K-dramas",
        category: "K-Drama",
        difficulty: 3,
        phrases: [
          { korean: "사랑해요", romanized: "saranghaeyo", meaning: "I love you" },
          { korean: "보고 싶어요", romanized: "bogo sipeoyo", meaning: "I miss you" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1617468264185-e6535390e9a4"
      },
      {
        id: 6,
        title: "Drama Conflicts",
        description: "Express emotions and resolve conflicts",
        category: "K-Drama",
        difficulty: 3,
        phrases: [
          { korean: "미안해요", romanized: "mianhaeyo", meaning: "I'm sorry" },
          { korean: "이해해요", romanized: "ihaehaeyo", meaning: "I understand" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1593085512500-5d55148d6f0d"
      },
      // K-Pop Lyrics
      {
        id: 7,
        title: "Popular Lyrics I",
        description: "Learn common phrases from K-pop hits",
        category: "K-Pop",
        difficulty: 4,
        phrases: [
          { korean: "우리 함께해요", romanized: "uri hamkkehaeyo", meaning: "Let's be together" },
          { korean: "다시 한번", romanized: "dashi hanbeon", meaning: "One more time" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1619855544858-e05e1c9d57e7"
      },
      // Cultural Etiquette
      {
        id: 8,
        title: "Respectful Speech",
        description: "Master honorifics and polite expressions",
        category: "Culture",
        difficulty: 4,
        phrases: [
          { korean: "죄송합니다", romanized: "joesonghamnida", meaning: "I'm sorry (very formal)" },
          { korean: "실례합니다", romanized: "sillyehamnida", meaning: "Excuse me (very formal)" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1585559700398-1385b3a8aeb5"
      },
      // Business Korean
      {
        id: 9,
        title: "Office Basics",
        description: "Essential business Korean expressions",
        category: "Business",
        difficulty: 5,
        phrases: [
          { korean: "회의", romanized: "hoeui", meaning: "Meeting" },
          { korean: "보고서", romanized: "bogoseo", meaning: "Report" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c"
      },
      {
        id: 10,
        title: "Email & Messages",
        description: "Professional communication in Korean",
        category: "Business",
        difficulty: 5,
        phrases: [
          { korean: "답장 드립니다", romanized: "dapjang deurimnida", meaning: "I'm replying (formal)" },
          { korean: "문의하신 건에 대해", romanized: "munuihasin geone daehae", meaning: "Regarding your inquiry" }
        ],
        imageUrl: "https://images.unsplash.com/photo-1557568192-2f79c2a1daa5"
      }
    ];

    sampleLessons.forEach(lesson => this.lessons.set(lesson.id, lesson));
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getLessons(): Promise<Lesson[]> {
    return Array.from(this.lessons.values());
  }

  async getLessonById(id: number): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }

  async getProgress(userId: number): Promise<Progress[]> {
    return Array.from(this.progress.values()).filter(
      (p) => p.userId === userId
    );
  }

  async updateProgress(insertProgress: InsertProgress): Promise<Progress> {
    const id = this.currentId.progress++;
    const progress: Progress = {
      id,
      userId: insertProgress.userId,
      lessonId: insertProgress.lessonId,
      completed: insertProgress.completed ?? false,
      score: insertProgress.score ?? 0
    };
    this.progress.set(id, progress);
    return progress;
  }

  async saveChat(insertChat: InsertChat): Promise<Chat> {
    const id = this.currentId.chats++;
    const chat: Chat = {
      ...insertChat,
      id,
      createdAt: new Date()
    };
    this.chats.set(id, chat);
    return chat;
  }

  async getUserChats(userId: number): Promise<Chat[]> {
    return Array.from(this.chats.values())
      .filter(chat => chat.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}

export const storage = new MemStorage();