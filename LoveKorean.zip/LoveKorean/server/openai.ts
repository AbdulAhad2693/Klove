import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `You are a friendly Korean language tutor. Respond to user messages in both Korean and English, 
helping them practice conversational Korean. Keep responses concise and encouraging. Focus on natural, everyday expressions 
commonly used in K-dramas and K-pop. When appropriate, reference Korean culture and entertainment.
Output format should be JSON with structure: { "korean": "...", "romanized": "...", "english": "...", "explanation": "..." }`;

export async function getChatResponse(message: string): Promise<{
  korean: string;
  romanized: string;
  english: string;
  explanation: string;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: message }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response content received from OpenAI");
    }

    try {
      const result = JSON.parse(content);
      if (!result.korean || !result.romanized || !result.english || !result.explanation) {
        throw new Error("Invalid response format from OpenAI");
      }
      return result;
    } catch (parseError) {
      console.error("Failed to parse OpenAI response:", content);
      throw new Error("Invalid JSON response from OpenAI");
    }
  } catch (error: unknown) {
    console.error("OpenAI API Error:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    throw new Error("Failed to get chat response: " + errorMessage);
  }
}