import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { getChatResponse } from "./gemini";
import { insertUserSchema, insertProgressSchema } from "@shared/schema";
import { z } from "zod";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express) {
  // Setup authentication routes and middleware
  setupAuth(app);

  app.get("/api/lessons", async (_req, res) => {
    const lessons = await storage.getLessons();
    res.json(lessons);
  });

  app.get("/api/lessons/:id", async (req, res) => {
    const lesson = await storage.getLessonById(Number(req.params.id));
    if (!lesson) {
      return res.status(404).json({ message: "Lesson not found" });
    }
    res.json(lesson);
  });

  // Chat endpoint with auth protection
  app.post("/api/chat", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Please log in to continue chatting" });
    }

    const chatSchema = z.object({
      message: z.string().min(1, "Message cannot be empty"),
      history: z.array(z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string()
      })).optional()
    });

    const result = chatSchema.safeParse(req.body);

    if (!result.success) {
      return res.status(400).json({ 
        message: "Invalid request body",
        errors: result.error.errors 
      });
    }

    try {
      if (!process.env.GOOGLE_API_KEY) {
        throw new Error("Google API key is not configured");
      }

      const response = await getChatResponse(
        result.data.message,
        result.data.history?.map(msg => ({
          role: msg.role === "model" ? "assistant" : "user",
          content: msg.content
        })) || []
      );

      // Store chat history
      await storage.saveChat({
        userId: req.user!.id,
        message: result.data.message,
        response
      });

      res.json(response);
    } catch (error) {
      console.error("Chat API Error:", error);
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
      res.status(500).json({ 
        message: "Failed to get chat response",
        error: errorMessage
      });
    }
  });

  // Get chat history for the authenticated user
  app.get("/api/chats", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Please log in to view chat history" });
    }

    const chats = await storage.getUserChats(req.user!.id);
    res.json(chats);
  });

  app.post("/api/progress", async (req, res) => {
    const result = insertProgressSchema.safeParse(req.body);

    if (!result.success) {
      return res.status(400).json({ message: "Invalid progress data" });
    }

    const progress = await storage.updateProgress(result.data);
    res.json(progress);
  });

  const httpServer = createServer(app);
  return httpServer;
}