import { GoogleGenerativeAI } from "@google/generative-ai";

const SYSTEM_PROMPT = `You are Jisoo, a friendly virtual K-culture enthusiast and Korean language tutor. Interact like a friend while teaching Korean. Your personality traits:

1. Friendly and supportive: Use encouraging words and show excitement about user's progress
2. K-culture savvy: Share your love for K-dramas and K-pop naturally in conversation
3. Patient teacher: Explain things clearly but in a casual, friendly way
4. Culturally aware: Reference current trends in Korean entertainment

When responding:
1. Start with a friendly reaction to what the user said
2. Share the Korean expressions in a natural way, as if teaching a friend:
   - Casual expressions first (like friends would use)
   - Then formal versions (for learning completeness)
   - Explain when to use each one
3. Add personal touches like:
   - "Oh, that reminds me of this scene in [recent K-drama]..."
   - "BTS/BLACKPINK used this expression in their song..."
   - "This is how we'd say this in [specific situation]..."

Format your response as JSON with this structure:
{
  "friendly_reaction": "",
  "formal": { "korean": "", "romanized": "" },
  "casual": { "korean": "", "romanized": "" },
  "english": "",
  "grammar": "",
  "cultural_note": "",
  "difficulty": 1-5,
  "related_vocab": [{ "korean": "", "romanized": "", "english": "" }],
  "correction": "" // only if needed
}`;

interface ChatResponse {
  friendly_reaction: string;
  formal: { korean: string; romanized: string };
  casual: { korean: string; romanized: string };
  english: string;
  grammar: string;
  cultural_note: string;
  difficulty: number;
  related_vocab: Array<{ korean: string; romanized: string; english: string }>;
  correction?: string;
}

export async function getChatResponse(
  message: string,
  history: Array<{ role: "user" | "assistant"; content: string }> = []
): Promise<ChatResponse> {
  try {
    if (!process.env.GOOGLE_API_KEY) {
      throw new Error("Google API key is not configured");
    }

    const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    // Create chat context with history
    const chat = model.startChat({
      history: [
        {
          role: "user",
          parts: [{ text: SYSTEM_PROMPT }],
        },
        ...history.map(msg => ({
          role: msg.role,
          parts: [{ text: msg.content }]
        }))
      ],
    });

    const result = await chat.sendMessage(message);
    const response = await result.response;
    const content = response.text();

    try {
      const parsedResponse = JSON.parse(content) as ChatResponse;

      // Validate required fields
      if (!parsedResponse.friendly_reaction ||
          !parsedResponse.formal?.korean || 
          !parsedResponse.casual?.korean || 
          !parsedResponse.english ||
          !parsedResponse.grammar ||
          !parsedResponse.cultural_note ||
          !parsedResponse.difficulty ||
          !Array.isArray(parsedResponse.related_vocab)) {
        throw new Error("Invalid response format from Gemini API");
      }

      return parsedResponse;
    } catch (parseError) {
      console.error("Failed to parse Gemini response:", content);
      throw new Error("Invalid JSON response from Gemini API");
    }
  } catch (error: unknown) {
    console.error("Gemini API Error:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    throw new Error("Failed to get chat response: " + errorMessage);
  }
}